import os, requests
from telegram.ext import Application, CommandHandler, MessageHandler, filters

TOKEN = os.getenv("TELEGRAM_TOKEN")
API_URL = os.getenv("API_URL")

async def start(update, context):
    await update.message.reply_text("Hi! Send me a message and I'll call Cortensor API.")

async def handle(update, context):
    text = update.message.text
    payload = {"inputs": text}
    r = requests.post(f"{API_URL}/inference/textgen", json=payload)
    await update.message.reply_text(r.json())

app = Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle))
app.run_polling()
